package com.training.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.training.entity.Supplier;
import com.training.ifaces.MyDao;


public class SupplierDao  implements MyDao<Supplier> {

	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public int add(Supplier t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Supplier find(long phoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Supplier> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
