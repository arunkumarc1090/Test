package com.training.ifaces;

import java.util.List;


public interface MyDao<T> {

	public int add(T t);
	public T find(long phoneNumber);
	public List<T> findAll();
	
}
