package com.training.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.entity.Supplier;
import com.training.ifaces.MyDao;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("resources/bean.xml");
		
		  MyDao<Supplier> dao = ctx.getBean("dao",MyDao.class);
		  
		  Supplier supplier = ctx.getBean("supplier",Supplier.class);
		  
		    supplier.setSupplierId("CHN101");
		    supplier.setSupplierName("Abc Limited");
		    supplier.setPhoneNumber(9040400);
		    supplier.setCity("chennai");
		    
		    int row = dao.add(supplier);
		    
		    System.out.println(row + ":=Row Added");
	}

}
