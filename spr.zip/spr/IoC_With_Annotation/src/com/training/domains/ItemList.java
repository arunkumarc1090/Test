package com.training.domains;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("list")
public class ItemList {

	
	private List<Item> itemList;

	public List<Item> getItemList() {
		return itemList;
	}

	@Autowired
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	
	
	
}
