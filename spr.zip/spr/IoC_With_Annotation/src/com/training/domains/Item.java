package com.training.domains;

import org.springframework.stereotype.Component;

@Component
public class Item {

	private int itemNumber;
	private String itemName;
	private double ratePerUnit;
	
	
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getRatePerUnit() {
		return ratePerUnit;
	}
	public void setRatePerUnit(double ratePerUnit) {
		this.ratePerUnit = ratePerUnit;
	}
	@Override
	public String toString() {
		return "Item [itemNumber=" + itemNumber + ", itemName=" + itemName + ", ratePerUnit=" + ratePerUnit + "]";
	}
	
	
}
