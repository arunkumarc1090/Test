package com.training.domains;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("inv")
public class Invoice {

	@Autowired
	private Item item;
	
	@Autowired
	
	private Customer customer;

	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
	@PostConstruct
	public void init(){
		
		System.out.println("Init Method Called");
		
	}
	
	@PreDestroy
	public void destroy(){
		
		System.out.println("Destroy Method Called");
	}
}
