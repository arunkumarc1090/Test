package com.training.apps;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.training.domains.*;
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ConfigurableApplicationContext ctx = 
				  new ClassPathXmlApplicationContext("resources/bean.xml");
		
	      Invoice inv = ctx.getBean(Invoice.class);
		    
	       System.out.println(inv.getCustomer());
	       
	       Item item = inv.getItem();
	       
	        item.setItemNumber(101);
	        item.setItemName("Tv");
	        item.setRatePerUnit(23000);

	         //System.out.println(item);
	    
	          ItemList list = ctx.getBean(ItemList.class);
	          
	          for(Item it :list.getItemList())
	          {
	        	  System.out.println(it);
	          }

	          ctx.close();
	}

}
