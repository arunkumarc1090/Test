package com.training.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.ifaces.Calculator;

public class AspectJ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resources/aspectJBean.xml");
		
	    Calculator bean = ctx.getBean(Calculator.class);
	    
	    System.out.println(bean.getClass());

	     System.out.println(bean.simpleInterest(5000, 5, 8));
	     
	}

}
