package com.training.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.ifaces.IConverter;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resources/aopBean.xml");
		
		    IConverter bean = ctx.getBean(IConverter.class);
		    
		    System.out.println(bean.dollorToRupees(200));
		    
		    System.out.println(bean.euroToRupees(100));
		    
		    System.out.println(bean.getClass());
	}

}
