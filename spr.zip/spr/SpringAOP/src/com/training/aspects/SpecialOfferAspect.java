package com.training.aspects;

import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class SpecialOfferAspect {

	

	@Around("execution(* com.training.domains.SimpleInterestCalculator.*(..))")
	public Object offers(ProceedingJoinPoint pjp) throws Throwable
	{
		             
		  System.out.println("Before Method Invocation");
		      
		        Object[] args=  pjp.getArgs();
		        System.out.println("Argument "+args[2]);
		        Double  rateOfInt=(Double)args[2];
		         
		  Object obj = pjp.proceed(new Object[]{args[0],args[1],++rateOfInt});
		    System.out.println("After Method Invocation");
		    
		       //Double value =(Double)obj;
		       
		    //return value+1000;
		    
		    return obj;
	}
}
