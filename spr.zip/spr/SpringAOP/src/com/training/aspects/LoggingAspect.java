package com.training.aspects;

import java.util.logging.*;

import org.aspectj.lang.JoinPoint;
public class LoggingAspect {

	private static Logger log = Logger.getLogger("simple");
	
	public void logAdvice(JoinPoint jp){
		
		 log.info(jp.getSignature().getName());
	}
}
