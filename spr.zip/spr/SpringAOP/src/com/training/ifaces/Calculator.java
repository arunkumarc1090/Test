package com.training.ifaces;

import org.springframework.stereotype.Component;

@Component
public interface Calculator {

	public double simpleInterest(double principle,double years,double intRate);
	
	
}
