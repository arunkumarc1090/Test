package com.training.ifaces;

public interface IConverter {

	public double dollorToRupees(double dlrAmt);
	public double euroToRupees(double euroAmt);
}
