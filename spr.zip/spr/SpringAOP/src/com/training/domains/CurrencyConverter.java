package com.training.domains;

import com.training.ifaces.IConverter;

public class CurrencyConverter implements IConverter {

	@Override
	public double dollorToRupees(double dlrAmt) {
	
		return dlrAmt * 65.00;
	}

	@Override
	public double euroToRupees(double euroAmt) {
		return euroAmt * 75.00;
	}

}
