package com.training.domains;

import org.springframework.stereotype.Component;

import com.training.ifaces.Calculator;

@Component
public class SimpleInterestCalculator implements Calculator {

	@Override
	public double simpleInterest(double principle, double years, double intRate) {
		// TODO Auto-generated method stub
		return (principle* intRate * years)/100.00;
	}

}
