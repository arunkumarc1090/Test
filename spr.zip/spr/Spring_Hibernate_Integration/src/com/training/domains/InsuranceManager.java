package com.training.domains;

import java.io.Serializable;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.training.entity.Insurance;

public class InsuranceManager extends HibernateDaoSupport {

	 public Object addPolicy(Insurance obj)
	 {
		Long key = (Long) getHibernateTemplate().save(obj);
	      return key;
	 }
}
