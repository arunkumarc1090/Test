package com.training.entity;

public class LifeInsurance extends Insurance {

	
	private String policyType;
	private String paymentMode;
	
	
	
	public LifeInsurance(long policyNumber, String policyHolder, String policyType, String paymentMode) {
		super(policyNumber, policyHolder);
		this.policyType = policyType;
		this.paymentMode = paymentMode;
	}



	public String getPolicyType() {
		return policyType;
	}



	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}



	public String getPaymentMode() {
		return paymentMode;
	}



	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}



	@Override
	public String toString() {
		return "LifeInsurance [policyType=" + policyType + ", paymentMode=" + paymentMode + "]";
	}
	
	
	
}
