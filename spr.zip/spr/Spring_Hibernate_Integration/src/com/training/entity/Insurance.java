package com.training.entity;

public class Insurance {

	private long policyNumber;
	private String policyHolder;
	
	
	public Insurance() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Insurance(long policyNumber, String policyHolder) {
		super();
		this.policyNumber = policyNumber;
		this.policyHolder = policyHolder;
	}
	public long getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyHolder() {
		return policyHolder;
	}
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}
	@Override
	public String toString() {
		return "Insurance [policyNumber=" + policyNumber + ", policyHolder=" + policyHolder + "]";
	}
	
	
}
