package com.training.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.domains.InsuranceManager;
import com.training.entity.LifeInsurance;

public class Application {

	public static void main(String[] args) {

		ApplicationContext ctx = 
				 new ClassPathXmlApplicationContext("resources/bean.xml");
		 
		 LifeInsurance insurance = ctx.getBean(LifeInsurance.class);
		 
		 InsuranceManager mgr = ctx.getBean(InsuranceManager.class);
		 
		   mgr.addPolicy(insurance);
		   
		  // https://goo.gl/cgVOQu
		   
	}

}
