package com.training.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.training.daos.CustomerDAO;
import com.training.entity.Customer;

@Controller
public class WelcomeController {

	@Autowired
	private ModelAndView modelAndView;

	@Autowired
	private CustomerDAO dao;
	
	@RequestMapping("/")
	 public ModelAndView  execute(){
		 
		 
		modelAndView.setViewName("index");
		 
		modelAndView.addObject("msg", "Welcome to Spring MVC");
		 
		 return modelAndView;
	 }
	
	@RequestMapping("/GetCustomer")
	public String getData(@RequestParam("customerId") long custId, Model model){
		
		Customer cust=dao.findbyId(custId);
		 model.addAttribute("foundCustomer", cust);
		System.out.println(cust);
		return "Show";
	}
}
