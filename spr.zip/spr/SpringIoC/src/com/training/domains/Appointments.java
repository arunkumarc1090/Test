package com.training.domains;
import java.util.*;
public class Appointments {

	private Doctor doctor;
	private Set<Patient> patientList;
	
	public Appointments() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public Set<Patient> getPatientList() {
		return patientList;
	}
	public void setPatientList(Set<Patient> patientList) {
		this.patientList = patientList;
	}
	@Override
	public String toString() {
		return "Appointments [doctor=" + doctor + ", patientList=" + patientList + "]";
	}
	
	
}
