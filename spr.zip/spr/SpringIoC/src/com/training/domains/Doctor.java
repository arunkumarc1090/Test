package com.training.domains;

public class Doctor {

	 private long doctorCode;
	 private String doctorName;
	 private long handPhone;
	  private String specialization;
	  

	  
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor(long doctorCode, String doctorName, long handPhone, String specialization) {
		super();
		this.doctorCode = doctorCode;
		this.doctorName = doctorName;
		this.handPhone = handPhone;
		this.specialization = specialization;
	}
	public long getDoctorCode() {
		return doctorCode;
	}
	public void setDoctorCode(long doctorCode) {
		this.doctorCode = doctorCode;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public long getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(long handPhone) {
		this.handPhone = handPhone;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	@Override
	public String toString() {
		return "Doctor [doctorCode=" + doctorCode + ", doctorName=" + doctorName + ", handPhone=" + handPhone
				+ ", specialization=" + specialization + "]";
	}
	  
	  
}
