package com.training.domains;

import java.util.logging.Logger;

public class Patient {

	
	/*
	 *  Three Dependency of Simple Values
	 */
	 private long patientId;
	 private String patientName;
	 private long handPhone;
	
	  private Doctor doctor;
	  
	 public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	private Logger log =Logger.getLogger(this.getClass().getName());
	 
	public Patient() {
		super();
	
		log.info("Patient Initialized");
	}
	public Patient(long patientId, String patientName, long handPhone) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.handPhone = handPhone;
	}
	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(long patientId) {
		
		log.info("Set Patient Id Called");
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public long getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(long handPhone) {
		this.handPhone = handPhone;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", handPhone=" + handPhone+"]";
		
	}
	 
	 
	 
	 
}
