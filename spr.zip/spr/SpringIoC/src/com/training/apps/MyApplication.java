package com.training.apps;

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.domains.Appointments;
import com.training.domains.Patient;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resources/application.xml");
		
		Appointments obj = ctx.getBean(Appointments.class);
		
		System.out.println("Appointment for Doctor :="+obj.getDoctor());
		
		Set<Patient> patList = obj.getPatientList();
		
		for(Patient patient :patList)
		{
			System.out.println(patient);
		}

	}

}
