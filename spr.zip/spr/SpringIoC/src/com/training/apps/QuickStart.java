package com.training.apps;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.training.domains.Doctor;
import com.training.domains.Patient;

public class QuickStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 BeanFactory ctx = new FileSystemXmlApplicationContext("bean.xml");
		 
		  Patient patient = ctx.getBean("patient2",Patient.class);
		  
		  System.out.println(patient);
		  
           
		  System.out.println(patient.getDoctor());
		  
		  
		  
          
          
	}

}
