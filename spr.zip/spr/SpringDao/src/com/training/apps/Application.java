package com.training.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.daos.CustomerDAO;
import com.training.entity.*;
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ApplicationContext  ctx = new ClassPathXmlApplicationContext("resources/bean.xml");
		
		
	Customer cust = ctx.getBean(Customer.class);

	 cust.setCustomerId(102);
	 cust.setCustomerName("Ganesh");
	 cust.setHandPhone(49494949);
	Address addr = ctx.getBean(Address.class);

	  addr.setAddrLine1("Pune");
	  addr.setAddrLine2("Pune");
	  addr.setCity("Pune");
	  addr.setPinCode(202020);
	  
	  cust.setBillingAddress(addr);
	  cust.setShippingAddress(addr);
	  		
	CustomerDAO dao = ctx.getBean(CustomerDAO.class);
	
		//int result = dao.add(cust);
		
	//System.out.println(result +":=Inserted");
		
             System.out.println(dao.findbyId(101));
	}

}
