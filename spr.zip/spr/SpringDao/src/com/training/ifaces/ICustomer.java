package com.training.ifaces;
import java.util.*;
import com.training.entity.*;

public interface ICustomer {

	public int add(Customer customer);
	public Customer findbyId(long custId);
	public List<Customer> findAll();
	
}
