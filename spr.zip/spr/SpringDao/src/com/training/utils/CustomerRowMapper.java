package com.training.utils;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.training.entity.Address;
import com.training.entity.Customer;


public class CustomerRowMapper implements RowMapper<Customer> {

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {

		Customer cust = new Customer();
		
		cust.setCustomerId(rs.getLong("customerId"));
		cust.setCustomerName(rs.getString("customerName"));
		cust.setHandPhone(rs.getLong("handPhone"));
		
		Address baddr = new Address(rs.getString("billAddrLine1"),
				         rs.getString("billAddrLine2"),rs.getString("billCity"),rs.getLong("billPin"));
		
		Address saddr = new Address(rs.getString("shipAddrLine1"),
		         rs.getString("shipAddrLine2"),rs.getString("shipCity"),rs.getLong("shipPin"));

		cust.setBillingAddress(baddr);
		cust.setShippingAddress(saddr);

		return cust;
	}

}
