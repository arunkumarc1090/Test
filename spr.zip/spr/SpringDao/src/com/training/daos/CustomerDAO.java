package com.training.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.training.entity.Customer;
import com.training.ifaces.ICustomer;
import com.training.utils.CustomerRowMapper;

public class CustomerDAO  implements ICustomer {

	@Autowired
    private JdbcTemplate jdbcTemplate;

	
	@Override
	public int add(Customer customer) {
	
		 String sql = "insert into scopeCustomer values(?,?,?,?,?,?,?,?,?,?,?)";
		 
		 int result =jdbcTemplate.update(sql,customer.getCustomerId(),customer.getCustomerName(),
				        customer.getHandPhone(),customer.getBillingAddress().getAddrLine1(),
				        customer.getBillingAddress().getAddrLine2(),customer.getBillingAddress().getCity(),
				        customer.getBillingAddress().getPinCode(),customer.getShippingAddress().getAddrLine1(),
				        customer.getShippingAddress().getAddrLine2(),customer.getShippingAddress().getCity(),
				        customer.getShippingAddress().getPinCode());
		return result;
	}

	@Autowired
	private CustomerRowMapper mapper;
	@Override
	public Customer findbyId(long custId) {
		
		String sql = "select * from scopeCustomer where customerId=?";
		Customer cust =jdbcTemplate.queryForObject(sql,mapper,custId);
		
		return cust;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
