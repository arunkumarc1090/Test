package com.training.entity;

public class Supplier {

private String supplierId;
private String supplierName;
private Address address;
private String city;
private long phoneNumber;

public String getSupplierId() {
	return supplierId;
}

public void setSupplierId(String supplierId) {
	this.supplierId = supplierId;
}

public String getSupplierName() {
	return supplierName;
}

public void setSupplierName(String supplierName) {
	this.supplierName = supplierName;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public long getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}

public Supplier() {
	super();
	// TODO Auto-generated constructor stub
}

public Supplier(String supplierId, String supplierName, Address address, String city, long phoneNumber) {
	super();
	this.supplierId = supplierId;
	this.supplierName = supplierName;
	this.address = address;
	this.city = city;
	this.phoneNumber = phoneNumber;
}

@Override
public String toString() {
	return "Supplier [supplierId=" + supplierId + ", supplierName=" + supplierName + ", address=" + address + ", city="
			+ city + ", phoneNumber=" + phoneNumber + "]";
}


}
