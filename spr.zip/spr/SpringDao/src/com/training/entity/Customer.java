package com.training.entity;

import org.springframework.stereotype.Component;

@Component
public class Customer {

	 private long customerId;
	 private String customerName;
	 private long handPhone;
	 private Address billingAddress;
	 private Address shippingAddress;
	 
	public Customer() {
		super();
	}
	public Customer(long customerId, String customerName, long handPhone, Address billingAddress,
			Address shippingAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.handPhone = handPhone;
		this.billingAddress = billingAddress;
		this.shippingAddress = shippingAddress;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(long handPhone) {
		this.handPhone = handPhone;
	}
	public Address getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}
	public Address getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", handPhone=" + handPhone
				+ ", billingAddress=" + billingAddress + ", shippingAddress=" + shippingAddress + "]";
	}
	 
	 
}
