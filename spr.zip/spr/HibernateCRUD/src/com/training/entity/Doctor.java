package com.training.entity;

import java.io.Serializable;
import java.util.*;
public class Doctor implements Serializable {

	// To Be Used as Identifier
	
	 private long doctorCode;
	 private String doctorName;
	 private String specialization;
	 private long handPhone;
	 
	 private Set<Patient> patientList;
	 
	public Doctor(long doctorCode, String doctorName, String specialization, long handPhone, Set<Patient> patientList) {
		super();
		this.doctorCode = doctorCode;
		this.doctorName = doctorName;
		this.specialization = specialization;
		this.handPhone = handPhone;
		this.patientList = patientList;
	}
	public Set<Patient> getPatientList() {
		return patientList;
	}
	public void setPatientList(Set<Patient> patientList) {
		this.patientList = patientList;
	}
	public Doctor() {
		super();
	}
	public Doctor(long doctorCode, String doctorName, String specialization, long handPhone) {
		super();
		this.doctorCode = doctorCode;
		this.doctorName = doctorName;
		this.specialization = specialization;
		this.handPhone = handPhone;
	}
	public long getDoctorCode() {
		return doctorCode;
	}
	public void setDoctorCode(long doctorCode) {
		this.doctorCode = doctorCode;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public long getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(long handPhone) {
		this.handPhone = handPhone;
	}
	@Override
	public String toString() {
		return "Doctor [doctorCode=" + doctorCode + ", doctorName=" + doctorName + ", specialization=" + specialization
				+ ", handPhone=" + handPhone + "]";
	}
	 
	 
	 
	 
}
