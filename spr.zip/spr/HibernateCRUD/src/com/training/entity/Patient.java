package com.training.entity;

public class Patient {

	private long patientNumber;
	private String patientName;
	
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(long patientNumber, String patientName) {
		super();
		this.patientNumber = patientNumber;
		this.patientName = patientName;
	}
	public long getPatientNumber() {
		return patientNumber;
	}
	public void setPatientNumber(long patientNumber) {
		this.patientNumber = patientNumber;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	@Override
	public String toString() {
		return "Patient [patientNumber=" + patientNumber + ", patientName=" + patientName + "]";
	}
	
	
}
