package com.trainng.apps;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.training.entity.Doctor;
import com.training.entity.Patient;

public class One2Many {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 Patient pat1 = new Patient(101, "Ganesh");
		 Patient pat2 = new Patient(102, "Suresh");
		 Patient pat3 = new Patient(103, "Magesh");
		 
		 
		 Set<Patient> patList = new HashSet<Patient>();
		 
		 patList.add(pat1);
		 
		 patList.add(pat2);
		 
		 patList.add(pat3);
		 
		 
		 Doctor doc = new Doctor(202,"Ramesh","Eye",894949,patList);
		 
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			
			//session.save(doc);
			
			        /*Doctor doc2 =(Doctor) session.get(Doctor.class, 202L);
			        
			        System.out.println(doc2);
			        System.out.println(doc2.getPatientList());
			        */
			        
			Criteria crt = session.createCriteria(Doctor.class);
			
			  crt.add(Restrictions.eq("doctorName","Ramesh" ));
			  crt.add(Restrictions.gt("doctorCode", 102L));
			  
			    List<Doctor> docList = crt.list();
			    
			    System.out.println(docList);
			    
			tx.commit();
	}

}
