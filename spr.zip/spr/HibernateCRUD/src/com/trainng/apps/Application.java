package com.trainng.apps;

import java.util.List;

import com.training.entity.Doctor;
import com.trainng.daos.DoctorDAO;
import com.trainng.daos.MyDao;

public class Application {

	public static void main(String[] args) {

		
		   MyDao<Doctor>  dao = new DoctorDAO();
		   
//		    long rowsAdded = dao.add(new Doctor(103,"Rakesh","Eye",040404));
//		    
//		    System.out.println(rowsAdded +":=  Added");
//		    
		    
		   
		   List<Doctor> docList = dao.findAll();
		   
		   System.out.println(docList);
		   
		   
	}

}
