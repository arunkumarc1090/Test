package com.trainng.daos;

import java.util.List;

public interface MyDao<T> {

	 public long add(T t);
	 public T find(long key);
	 public List<T> findAll();
	 public int remove(long key);
}
