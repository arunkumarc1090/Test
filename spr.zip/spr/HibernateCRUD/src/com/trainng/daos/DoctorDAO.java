package com.trainng.daos;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.hibernate.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.training.entity.Doctor;

public class DoctorDAO implements MyDao<Doctor> {
	
	
   private SessionFactory factory;
   private Session session;
   private Transaction tx;
	public DoctorDAO() {
		super();
		
		factory = new Configuration().configure().buildSessionFactory();
		session = factory.openSession();
		tx = session.beginTransaction();
	}

	@Override
	public long add(Doctor t) {
	
		 long  key = (Long)session.save(t);
		 tx.commit();
		return key;
	}

	@Override
	public Doctor find(long key) {
		
		Doctor doc = (Doctor)session.get(Doctor.class, key);
		
		doc.setDoctorName("Ramesh Kumar ");
		
		session.getTransaction().commit();
		return doc;
	}
	@Override
	public List<Doctor> findAll() {
		List<Doctor> docList = session.createQuery("from Doctor").list();
		
		return docList;
	}

	@Override
	public int remove(long key) {

		Doctor doc = (Doctor)session.get(Doctor.class, key);
              
		         session.delete(doc);
		         
		         tx.commit();
		return 0;
	}


	public void clean(){
		System.out.println("Inside Pre Destroy");
		session.close();
		factory.close();
	}
}
