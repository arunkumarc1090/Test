package com.threads;

public class BankAccount {

	private double balance=2000;

	public synchronized double deposit(double amount){

	System.out.println("Deposit Amount = " +amount);
	balance = balance + amount;
	System.out.println("After Deposit, Current Balane = " +balance);
	notify();
	return balance;
	
	}
	
	public synchronized double withdraw(double amount){
		
	if(balance < amount){
		
		System.out.println("Current Balane: " +balance);
		System.out.println("Withdraw Amount = " +amount);
		System.out.println("In sufficent Balance");
		try {
			wait();
			if(balance < amount){
				System.out.println("In sufficent Balance, plz add some amount");
				return 0;
		}
			System.out.println("Withdraw Amount = " +amount);
		}catch(InterruptedException e) {
			e.printStackTrace();
	    }
	}
	 balance = balance - amount;
	 System.out.println("After withdrawl, Current Balane: " +balance);

	 return balance;
	}
	
}
