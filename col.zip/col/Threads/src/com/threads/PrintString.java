package com.threads;

public class PrintString {

	public synchronized static void print(String str1,String str2){
		System.out.println(str1);
		System.out.println(str2);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		
		
	}
}
