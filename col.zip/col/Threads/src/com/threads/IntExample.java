package com.threads;

import java.util.Locale;
import java.util.ResourceBundle;



public class IntExample {

	public static void main(String[] args) {
	
		ResourceBundle rs = ResourceBundle.getBundle("a1", Locale.GERMAN);
		System.out.println(rs.getString("MornGreet"));
		System.out.println(rs.getString("Morneve"));
		
//		ResourceBundle rs1 = ResourceBundle.getBundle("a2", Locale.ITALY);
//		System.out.println(rs1.getString("MornGreet"));
//		System.out.println(rs1.getString("Morneve"));
		
	}

}
