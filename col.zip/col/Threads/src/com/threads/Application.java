package com.threads;

public class Application {

	public static void main(String []args){
		
		new UsePrintString("Hi", "Hello");
		new UsePrintString("Thread", "Running");
		
	}
}
