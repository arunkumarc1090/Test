package com.threads;

class Reader implements Runnable{

	@Override
	public void run() {
		System.out.println("Current Thread :" +Thread.currentThread().getName());
		System.out.println("reading...");
		try{
		System.in.read();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("finished reading");
	}
			
}

public class JoinExample {

	public static void main(String[] args) {
		System.out.println("Main starting....");
		System.out.println("Main Thread :" +Thread.currentThread().getName());
		Reader reade=new Reader();
		Thread t1= new Thread(reade);
		t1.start();
		try{
			t1.join();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Main finished");
	}

}
