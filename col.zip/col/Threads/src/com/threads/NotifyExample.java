package com.threads;

public class NotifyExample {

	public static void main(String[] args) {

		BankAccount bk1 = new BankAccount();
		Thread t1=new Thread(){
			
		public void run(){
			bk1.withdraw(14000);
//			double balance = bk1.withdraw(4000);
//			System.out.println("Balance " +balance);
		}   
		};
		
		t1.start();
		
		Thread t2=new Thread(){
			public void run(){
				bk1.deposit(12000);
//				double balance = bk1.deposit(3000);
//				System.out.println("Balance " +balance);
		}
		};
		t2.start();
		}

}
