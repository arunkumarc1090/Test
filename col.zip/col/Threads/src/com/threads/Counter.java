package com.threads;

public class Counter implements Runnable {

	private int max;
	
	public Counter(int max) {
		super();
		this.max = max;
	}
	
	@Override
	public void run() {

		double counter=0;
		for(int i=0;i<=max;i++){
			counter = counter+i;
	}
		System.out.println("Counetr: " +counter);

	}

	public static void main(String args[]){
		
		Thread t1 = new Thread(new Counter(100));
		Thread t2 = new Thread(new Counter(20));
		Thread t3 = new Thread(new Counter(30));
		t1.start();
		t2.start();
		t3.start();
	}
}
