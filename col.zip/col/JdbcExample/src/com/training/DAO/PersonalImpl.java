package com.training.DAO;

import java.util.List;

import com.training.util.PersonalLoan;

public class PersonalImpl implements GenericDAO<PersonalLoan> {

	@Override
	public int add(PersonalLoan t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<PersonalLoan> findall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonalLoan findByid(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int remove(long id) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
