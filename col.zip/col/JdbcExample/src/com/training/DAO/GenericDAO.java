package com.training.DAO;

import java.util.List;

public interface GenericDAO<T> {
	public int add(T t);
	public List<T> findall();
	public T findByid(long id);
	public int remove(long id);
	
}
