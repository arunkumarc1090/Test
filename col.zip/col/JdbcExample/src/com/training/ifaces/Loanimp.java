package com.training.ifaces;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import com.training.util.DbConnection;
import com.training.util.PersonalLoan;

public class Loanimp implements Loan {

	Connection con = DbConnection.getOracleConnection();
	public Loanimp(){
		
	}
	
	@Override
	public int removeLoan(Long loanid) throws SQLException{

		PreparedStatement pss = con.prepareStatement("Delete from PersonalLoan where loanid=?");
		pss.setLong(1,loanid);
		int rowdelete = pss.executeUpdate();
		return rowdelete;
	}

	@Override
	public int add(PersonalLoan loan) throws SQLException{
		String sql = "Insert into PersonalLoan values (?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setLong(1,loan.getLoanid());
		ps.setString(2,loan.getCustomerName());
		ps.setDouble(3,loan.getLoanamt());
		ps.setDouble(4,loan.getEmi());
		int rowsAdded = ps.executeUpdate();
		return rowsAdded;
	}

	@Override
	public List<PersonalLoan> findall() throws SQLException {
		List<PersonalLoan> list = new ArrayList<PersonalLoan>();
		String sqls = "Select * from PersonalLoan";
		PreparedStatement ps = con.prepareStatement(sqls);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			PersonalLoan loan = getLoanobject(rs);
			list.add(loan);
		}
		
		return list;
	}
	
	private PersonalLoan getLoanobject(ResultSet rs) throws SQLException{
		long a= rs.getLong("Loanid");
		 String s= rs.getString("CustomerName");
		 double d= rs.getDouble("Loanamt");
		 double de= rs.getDouble("Emi");
		 
		 PersonalLoan loan = new PersonalLoan(a,s,d,de);
		return loan;
	}

	@Override
	public PersonalLoan findByid(long loanid) throws SQLException{
	
		String se = "select * from PersonalLoan where loanid=?";
		PreparedStatement ps = con.prepareStatement(se);
		ps.setLong(1,loanid);
		ResultSet rs = ps.executeQuery();
		PersonalLoan loan= null;
		if(rs.next()){
			 loan = getLoanobject(rs);
//		 long a= rs.getLong("Loanid");
//		 String s= rs.getString("CustomerName");
//		 double d= rs.getDouble("Loanamt");
//		 double de= rs.getDouble("Emi");
//		 
//		 loan = new PersonalLoan(a,s,d,de);
		 
		}
		
		return loan;
	}

	@Override
	public int updateEMI(long loanid, double revalueEMI) throws SQLException {
		
		CallableStatement cs = con.prepareCall("call updateEMI(?,?,?)");
		cs.setLong(1,loanid);
		cs.setDouble(2,revalueEMI);
		cs.registerOutParameter(3, Types.NUMERIC);
		Boolean result = cs.execute();
		int rowupdated = cs.getInt(3);
			
		return rowupdated;
	}

	@Override
	public TreeSet<PersonalLoan> sortAllByName() throws SQLException {
		
		TreeSet<PersonalLoan> loanlist = new TreeSet<PersonalLoan>();
		String oh = "select * from PersonalLoan";
		PreparedStatement ps = con.prepareStatement(oh);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			PersonalLoan loan = getLoanobject(rs);
			loanlist.add(loan);
		}
		
		return loanlist;
		
	
	}
}


