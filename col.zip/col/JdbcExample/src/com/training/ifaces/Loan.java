package com.training.ifaces;

import java.sql.SQLException;
import com.training.util.PersonalLoan;
import java.util.*;
public interface Loan {

	public int add(PersonalLoan loan) throws SQLException;
	public PersonalLoan findByid(long loanid)throws SQLException;
	public int removeLoan(Long loanid)throws SQLException;
	public List<PersonalLoan> findall() throws SQLException;
	public int updateEMI(long loanid,double revalueEMI) throws SQLException;
	
	public TreeSet<PersonalLoan> sortAllByName() throws SQLException; 
}
