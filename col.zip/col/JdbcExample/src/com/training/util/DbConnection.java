package com.training.util;
import java.io.FileInputStream;
import java.sql.*;
import java.util.Properties;
public class DbConnection {

	public static Connection getOracleConnection(){
		Connection con =null;
		try{
			Properties props = new Properties();
			FileInputStream fis = new FileInputStream("DBConnection.properties");
			props.load(fis);
			Class.forName(props.getProperty("db.driverClass"));
			con = DriverManager.getConnection(
					props.getProperty("db.url"),
					props.getProperty("db.userName"),
					props.getProperty("db.passWord"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return con;
	}
}
