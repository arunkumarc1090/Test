package com.training.util;

public class PersonalLoan implements Comparable<PersonalLoan> {

	private long loanid;
	private String CustomerName;
	private double loanamt;
	private double emi;
	public PersonalLoan() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PersonalLoan(long loanid, String customerName, double loanamt, double emi) {
		super();
		this.loanid = loanid;
		CustomerName = customerName;
		this.loanamt = loanamt;
		this.emi = emi;
	}
	public long getLoanid() {
		return loanid;
	}
	public void setLoanid(long loanid) {
		this.loanid = loanid;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public double getLoanamt() {
		return loanamt;
	}
	public void setLoanamt(double loanamt) {
		this.loanamt = loanamt;
	}
	public double getEmi() {
		return emi;
	}
	public void setEmi(double emi) {
		this.emi = emi;
	}
	@Override
	public String toString() {
		return "PersonalLoan [loanid=" + loanid + ", CustomerName=" + CustomerName + ", loanamt=" + loanamt + ", emi="
				+ emi + "]";
	}
	@Override
	public int compareTo(PersonalLoan o) {
		
		return this.CustomerName.compareTo(o.CustomerName);
	}
	
	
}
