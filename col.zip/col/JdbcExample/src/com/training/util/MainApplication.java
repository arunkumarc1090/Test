package com.training.util;
import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

import com.training.ifaces.*;
public class MainApplication {

	public static void print(Collection<PersonalLoan>loanlist){
		
		for(PersonalLoan eachloan:loanlist){
			System.out.println(eachloan.getCustomerName() +eachloan.getLoanamt());
		}
	}
	public static void main(String[] args) {
//		Connection con = DbConnection.getOracleConnection();
//		System.out.println(DbConnection.getOracleConnection());	
		PersonalLoan loan = new PersonalLoan(12123,"Good",12314,31315);
		Loanimp li = new Loanimp();
	
		
		
		int key =6;
		try{
		switch(key){
		case 1:
			int rowAdded = li.add(loan);
			System.out.println(rowAdded +"rowadded");
			break;
		case 2:
			long loanid = Long.parseLong(args[0]);
			PersonalLoan loan1 = li.findByid(loanid);
			if (loan1!=null){
				System.out.println(" found");
			}else
			{
				System.out.println("not found");
			}
			break;
		case 3:
			int rowdeleted = li.removeLoan((long) 12123);
			if (rowdeleted==1){
               System.out.println("row deleted");				
			}
			break;
		
		case 4:
			List<PersonalLoan> loanlist= li.findall();
//			print(loanlist);
			System.out.println("result " +loanlist);
			break;
		case 5:
			int rowsupadated = li.updateEMI(12123 , 1000);
			System.out.println("rowupdated " +rowsupadated);
			break;
		case 6:
			
			// Collection Tree set example
			TreeSet<PersonalLoan> treeset = li.sortAllByName();
			print(treeset);
			break;
		
			
		default:
				break;
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		}
	}


