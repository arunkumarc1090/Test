
public class Car {

	private String category;
	private String price;
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Car(String category, String price) {
		super();
		this.category = category;
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Car [category=" + category + ", price=" + price + "]";
	}
	
	
}
