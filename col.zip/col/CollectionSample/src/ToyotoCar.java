
public class ToyotoCar extends Car {

	private String manufLoaction;

	public ToyotoCar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ToyotoCar(String category, String price, String manufLoaction) {
		super(category, price);
		this.manufLoaction = manufLoaction;
	}

	public String getManufLoaction() {
		return manufLoaction;
	}

	public void setManufLoaction(String manufLoaction) {
		this.manufLoaction = manufLoaction;
	}

	@Override
	public String toString() {
		return "ToyotoCar [manufLoaction=" + manufLoaction + "]";
	}

	
}
