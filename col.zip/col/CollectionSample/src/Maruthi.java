
public class Maruthi extends Car {

	private String model;
	private String varient;
	private boolean isBharatStage4;
	public Maruthi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Maruthi(String category, String price, String model, String varient, boolean isBharatStage4) {
		super(category, price);
		this.model = model;
		this.varient = varient;
		this.isBharatStage4 = isBharatStage4;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getVarient() {
		return varient;
	}
	public void setVarient(String varient) {
		this.varient = varient;
	}
	public boolean isBharatStage4() {
		return isBharatStage4;
	}
	public void setBharatStage4(boolean isBharatStage4) {
		this.isBharatStage4 = isBharatStage4;
	}
	@Override
	public String toString() {
		return "Maruthi [model=" + model + ", varient=" + varient + ", isBharatStage4=" + isBharatStage4 + "]";
	}
	
	
	
}
