import java.util.*;

public class MapExample {

	public static void main(String[] args) {
		
		HashMap <String,List<String>> syns = new HashMap<String,List<String>>();
		List<String> read = new ArrayList<String>();
		read.add("AS");
		read.add("ASD");
		read.add("SDER");
		read.add("TER");
		
		List<String> stng = new ArrayList<String>();
		stng.add("hsd");
		stng.add("ew");
		stng.add("tt");
		
		syns.put("read", read);
		syns.put("stng", stng);
		
		List<String> equivalent = syns.get(args[0]);
		if(equivalent!=null){
		for (String s : equivalent){
			System.out.println("MapExample: " +s);
		}
		}else{
			System.out.println("Word not found");
		}
	}

}
