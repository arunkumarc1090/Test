import java.util.*;

public class MapExample2 {

	public static void main(String[] args) {
		
		HashMap <String,List<String>> syns = new HashMap<String,List<String>>();
		List<String> read = new ArrayList<String>();
		read.add("AS");
		read.add("ASD");
		read.add("SDER");
		read.add("TER");
		
		List<String> stng = new ArrayList<String>();
		stng.add("hsd");
		stng.add("ew");
		stng.add("tt");
		
		syns.put("read", read);
		syns.put("stng", stng);
		
		//map to set conversion for iteration
		Set<Map.Entry<String,List<String>>> data = syns.entrySet();
		Iterator<Map.Entry<String, List<String>>> itr =data.iterator();
		while(itr.hasNext()){
			
			Map.Entry<String, List<String>> singleEntry = itr.next();
			System.out.println("MapExam:" +singleEntry.getKey());
			List<String> value = singleEntry.getValue();
			
			for(String s:value){
				System.out.println(s);
			}
			
		}
	}

}
