import java.util.ArrayList;
import java.util.*;


public class AppExample {

	public static void main (String args[]){
	List <String> names = new ArrayList<String>();
	
	names.add("c");
	names.add("a");
	names.add("b");
	names.add("z");
	names.add("t");
	names.add("y");
	
	Collections.sort(names);
	System.out.println("output : " +names);
	
	ArrayList<Customer> cusList = new ArrayList<Customer>();
	cusList.add(new Customer((101),"A",1234532123));
	cusList.add(new Customer((102),"V",1234531321));
	cusList.add(new Customer((103),"Y",1234578877));
	cusList.add(new Customer((104),"U",1234587545));
	cusList.add(new Customer((105),"W",1234587887));
	Collections.sort(cusList);
	
	for(Customer c: cusList){
		
		System.out.println("output : " + c.getCustomerName());		
	}
	

	
	}
	
	
}
