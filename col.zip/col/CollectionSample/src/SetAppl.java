import java.util.HashSet;

public class SetAppl {

	public static void main(String []args){
		
		HashSet<Customer> cusList = new HashSet<Customer>();
		
		cusList.add(new Customer(101,"A",123456));
		cusList.add(new Customer(101,"V",678912));
		cusList.add(new Customer(105,"W",987654));
		
		Customer obj = new Customer(105,"W",187654);
		cusList.add(obj);
		
		System.out.println("Size " +cusList.size());
	}
}
