import java.util.*;

public class Collection_Generic_Bound {

	//Upper Bound
	public static void print(List<? extends Car>obj1){
		System.out.println(obj1.get(1));
//		obj1.add(new Maruthi());		// add operation not possible 
//		obj1.add(new ToyotoCar());
	}
	
	//Lower Bound
	public static void handle(List<? super Car>obj2){
		System.out.println(obj2.get(1));
		obj2.add(new Maruthi());		//add operation is possible
		obj2.add(new ToyotoCar());
	}
		
	public static void main(String[] args) {
	
		List<Car> Mcar = new ArrayList<Car>();
		//List<Car> - because of using super in handle function, we calling super class in the list
		
		Mcar.add(new Maruthi("HatchBack","50000","Celerio","Pertol",true));
		Mcar.add(new Maruthi("SUV","80000","Ertiga","Disel",true));
		print(Mcar);
		handle(Mcar);
		
		List<ToyotoCar> Tcar = new ArrayList<ToyotoCar>(); 
		//List<Toyoto> 
		
		Tcar.add(new ToyotoCar("HatchBack","50000","Toyoto1"));
		Tcar.add(new ToyotoCar("SUV","80000","Toyoto2"));
		print(Tcar);
		
		
	}

}
