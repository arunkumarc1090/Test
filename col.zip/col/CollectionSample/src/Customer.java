
public class Customer implements Comparable<Customer>{

	@Override
	public int compareTo(Customer o) {
	
//		if (this.customerid<o.customerid) return 1;
//		if (this.customerid>o.customerid) return -1;
//		return 0;
		return this.customerName.compareTo(o.customerName);
		
	}

	private int customerid;
	private String customerName;
	private long phoneNumber;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerid, String customerName, long phoneNumber) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + customerid;
		result = prime * result + (int) (phoneNumber ^ (phoneNumber >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (customerid != other.customerid)
			return false;
		if (phoneNumber != other.phoneNumber)
			return false;
		return true;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customerName=" + customerName + ", phoneNumber=" + phoneNumber
				+ "]";
	}
	
	
}
